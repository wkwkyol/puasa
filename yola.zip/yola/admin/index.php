<?php
session_start();
include("koneksi.php");

if (empty($_SESSION['username'])) {
  include('views/admin_portofolio/login.php');
} else {
  include("views/admin_portofolio/admin.php");
}
